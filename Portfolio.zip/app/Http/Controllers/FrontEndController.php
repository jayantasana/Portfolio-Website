<?php

namespace App\Http\Controllers;

use App\About;
use Illuminate\Http\Request;

class FrontEndController extends Controller
{

    // public function __construct()
    // {
    //     $this->middlware('verified');
    // }

    function Front(){
        $about = About::all();
        return view('frontend.front',[
            'about'=> $about,
        ]);
    }
}
